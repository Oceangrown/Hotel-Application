package Menu;


import api.AdminResource;
import api.HotelResource;
import model.Customer;
import model.IRoom;
import model.Reservation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;
import java.util.regex.Pattern;

import static Menu.AdminMenu.getRoomNumber;

public class MainMenu {
    public static MainMenu instanceMainMenu = null;
    private static Collection<IRoom> availableRooms = new HashSet<>();
    private static Collection<Customer> allCustomers = new HashSet<>();
    private static Collection<Reservation> reservationCollection = new HashSet<>();
    public static AdminResource instanceAdminResource =  AdminResource.getInstance();
    public static HotelResource instanceHotelResource = HotelResource.getInstance();

    private MainMenu(){}

    public static void launchMainMenu(){
        boolean keepRunning = true;
        String optionMainMenu = null;

        while(keepRunning){
            try{
                System.out.println("Welcome to the Hotel Reservation Application\n");
                System.out.println("---------------------------------------------");
                System.out.println("1. Find and Reserve a room");
                System.out.println("2. See my Reservations");
                System.out.println("3. Create an account");
                System.out.println("4. Admin");
                System.out.println("5. Exit");
                System.out.println("----------------------------------------------");
                System.out.println("Please select a number for the Menu option");
                optionMainMenu = getSwitchOption();
                System.out.println("** OptionMainMenu **" + optionMainMenu);
                switch (optionMainMenu){
                    case "1": findReserveRoom();
                    break;
                    case "2": seeReservations();
                    break;
                    case "3": String email = getEmail();
                    String firstName = getFirstOrLastName("First Name");
                    String lastName = getFirstOrLastName("Last Name");
                    instanceHotelResource.createACustomer(email, firstName, lastName);
                    break;
                    case "4": AdminMenu.launchAdminMenu();
                    break;
                    case "5": keepRunning = false;
                    break;
                    default: System.out.println("Please enter a number between 1-5");
                }


            }catch (Exception ex){
                System.out.println(ex.toString() + "\n");
            }
        }
        return;
    }
    public static void seeReservations(){
        reservationCollection.clear();
        String customersEmail = getEmail();
        reservationCollection = instanceHotelResource.getCustomerReservations(customersEmail);
        if(reservationCollection.isEmpty()){
            System.out.println("There are no reservations for this customer");
            return;
        } else{
            for(Reservation currentReservation : reservationCollection){
                currentReservation.toString();
            }
        }
        return;
    }
    public static String getSwitchOption(){
        String switchOption;
        Scanner mainMenuScanner = new Scanner(System.in);
        switchOption = mainMenuScanner.nextLine();
        return switchOption;
    }

    public static void findReserveRoom(){
        String yesNo;
        boolean keepRunning = true;

        Date checkInDate = getDate("CheckIn");
        Date checkOutDate = getDate("CheckOut");
        availableRooms = instanceHotelResource.findARoom(checkInDate, checkOutDate);
        if(availableRooms.isEmpty()){
            System.out.println("There are no rooms available within those dates.");
            return;
        }
        for(IRoom room : availableRooms){
            System.out.println(room.toString());
        }
        Scanner yesNoScan = new Scanner(System.in);
        while(keepRunning){
            try{
                System.out.println("Would you like to book a room? y/n");
                yesNo = yesNoScan.nextLine();
                if (yesNo.equals("y")){
                    callBookRoom(checkInDate,checkOutDate);
                    return;
                }
                if(yesNo.equals("n")){
                    return;
                } else {
                    throw new IllegalArgumentException("Error, invalid format, please enter y or n");
                }
            } catch(Exception ex){
                System.out.println("Error - Invalid input");
            }
        }
        return;
    }
    public static void callBookRoom(Date checkIn, Date checkOut){
        String yesNo;
        String roomNumber;
        IRoom room = null;
        boolean keepRunning = true;
        String email = null;
        String ynRegex = "[ynYN]";
        Pattern pattern = Pattern.compile(ynRegex);

        while (keepRunning){
            try{
                Scanner yesNoScan = new Scanner(System.in);
                System.out.println("Do you have an account with us? y/n");
                yesNo = yesNoScan.nextLine();

                if(!pattern.matcher(yesNo).matches()){
                    throw new IllegalArgumentException();
                } else if (yesNo.equals("y") || yesNo.equals("y")){
                    email = getEmail();

                    Customer customer = instanceHotelResource.getCustomer(email);
                    if (customer.equals(null)){
                        System.out.println("There are no customers in the database with this email, please try again");
                        throw new IllegalArgumentException();
                    }
                    roomNumber = getRoomNumber();
                    room = instanceHotelResource.getRoom(roomNumber);
                    instanceHotelResource.bookARoom(email, room, checkIn, checkOut);
                    keepRunning = false;

                }
                else if (yesNo.equals("n")){
                    keepRunning = false;
                }
            } catch(Exception ex){
                System.out.println("Error - Invalid Input");
            }
        }
    }
    public static String getRoomNumber(){
        boolean keepRunning = true;
        String roomID = null;
        String roomRegex = "([0-9]+)";
        Pattern pattern = Pattern.compile(roomRegex);

        while(keepRunning){
            try{
                Scanner roomScan = new Scanner(System.in);
                System.out.println("What room number would you like to reserve");
                roomID = roomScan.nextLine();

                if(!pattern.matcher(roomRegex).matches()){
                    System.out.println("Error, invalid room number format");
                    throw new IllegalArgumentException();
                }
                else{
                    keepRunning = false;
                }
            } catch(Exception ex){
                System.out.println("Error - Invalid input");
            }
        }
        return roomID;
    }

    public static String getEmail(){
        String email = null;
        String emailRegex = "^(.+)@(.+).(.+)$";
        Pattern pattern = Pattern.compile(emailRegex);
        boolean keepRunning = true;

        while (keepRunning){
            try{
                Scanner emailScan = new Scanner(System.in);
                System.out.println("Enter Email format: name@domain.com");
                email = emailScan.nextLine();
                if(!pattern.matcher(email).matches()){
                    throw new IllegalArgumentException();
                }
                else{
                    keepRunning = false;
                }
            } catch(Exception ex){
                System.out.println("Error, Invalid email format");
            }
        }
        return email;
    }
    public static String getFirstOrLastName(String nameType){
        String firstOrLastName = null;
        String nameRegex = "[A-Z]+(['-]*[a-zA-Z]+)*";
        Pattern pattern = Pattern.compile(nameRegex);

        boolean keepRunning = true;
        while (keepRunning){
            try{
                Scanner nameScan = new Scanner(System.in);
                System.out.println("nameType");
                firstOrLastName = nameScan.nextLine();
                if(!pattern.matcher(firstOrLastName).matches()){
                    throw new IllegalArgumentException();
                }
                else{
                    keepRunning = false;
                }
            } catch(Exception ex){
                System.out.println("Error- Invalid input");
            }
        }
        return firstOrLastName;
    }
    public static Date getDate(String dateType){
        Date validatedDate = null;
        boolean keepRunning = true;
        DateFormat dateFormat = new SimpleDateFormat("mm/dd/yyyy");
        String date;

        while(keepRunning){
            System.out.println("Enter " + dateType + "date mm/dd/yyyy example 06/14/2021");
            try{
                Scanner scanDate = new Scanner(System.in);
                date = scanDate.nextLine();
                validatedDate = dateFormat.parse(date);
            } catch(Exception ex){
                System.out.println("Error - Invalid input");
                continue;
            }
            keepRunning = false;
        }
        return validatedDate;
    }
}