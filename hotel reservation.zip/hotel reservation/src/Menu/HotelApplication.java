package Menu;



import static Menu.MainMenu.launchMainMenu;


public class HotelApplication {
    public static void main(String[] args) {
        launchMainMenu();
    }

}
