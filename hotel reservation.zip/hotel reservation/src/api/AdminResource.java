package api;

import model.Customer;
import model.IRoom;
import model.Room;
import model.RoomType;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.List;

public class AdminResource {
    public static AdminResource adminResource = new AdminResource();
    private CustomerService customerService = CustomerService.getInstance();
    private ReservationService reservationService = new ReservationService();


    public static AdminResource getReservationService() {
        return null;
    }
    public static AdminResource getInstance(){
        if (null == adminResource){
            adminResource = new AdminResource();
        }
        return adminResource;
    }

    public Customer getCustomer(String email){
        return customerService.getCustomer(email);
    }
    public void addRoomList(List<IRoom> rooms){
        for(IRoom room : rooms){
            reservationService.addRoom(room);
        }
    }
    public void makeRoom(String roomNumber, double roomPrice, RoomType enumeration){
        IRoom temp = new Room(roomNumber, roomPrice, enumeration);
        reservationService.addRoom(temp);
    }
    public Collection<Customer> getAllCustomers(){
        return customerService.getAllCustomers();
    }
    public void displayAllReservations(){
        reservationService.printAllReservations();
    }

    public Collection<IRoom> getAllRooms() {
        return null;
    }

    public Object addARoom(List<IRoom> roomList) {
        return null;
    }
}
