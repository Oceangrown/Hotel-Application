package api;

import model.Customer;
import model.IRoom;
import model.Reservation;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;

public class HotelResource {
    private static HotelResource hotelResource = new HotelResource();
    private CustomerService customerService = CustomerService.getInstance();
    private ReservationService reservationService = new ReservationService();

    public static HotelResource getHotelResource(){
        return null;
    }
    public static HotelResource getInstance(){
        if (null == hotelResource){
            hotelResource = new HotelResource();
        }
        return hotelResource;
    }

    public Customer getCustomer(String email) {
        return null;
    }
    public void createACustomer(String email, String firstName, String lastName){
        try{
            customerService.addCustomer(firstName, lastName, email);
        } catch (IllegalArgumentException ex){
            ex.getLocalizedMessage();
        }
    }
    public IRoom getRoom(String roomNumber){
        return reservationService.getRoom(roomNumber);
    }
    public Reservation bookARoom(String customerEmail, IRoom room, Date checkInDate, Date checkOutDate){
        return reservationService.reserveRoom(getCustomer(customerEmail), room, checkInDate, checkOutDate);
    }
    public Collection<Reservation> getCustomerReservations(String customerEmail){
        return reservationService.getCustomerReservations(getCustomer(customerEmail));

    }
    public Collection<IRoom> findARoom(Date checkInDate, Date checkOutDate){
        return reservationService.findRooms(checkInDate, checkOutDate);
    }


}
