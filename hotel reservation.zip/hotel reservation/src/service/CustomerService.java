package service;

import model.Customer;
import model.IRoom;
import model.Reservation;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import java.util.*;

public class CustomerService {

    private Collection<Customer> customers = new ArrayList<Customer>();
    private Map<String, Customer> mapOfCustomer = new HashMap<String, Customer>();

    private static CustomerService customerService = null;
    private CustomerService(){}

    public static CustomerService getInstance(){
        if (null == customerService){
            customerService = new CustomerService();
        }
        return customerService;
    }

    public void addCustomer(String firstName, String lastName, String email){
        Customer newCustomer = new Customer(firstName, lastName, email);
        this.customers.add(newCustomer);
        this.mapOfCustomer.put(newCustomer.getEmail(), newCustomer);
    }
    public Customer getCustomer(String customerEmail){
        String cusEmail = customerEmail.toLowerCase();
        Customer findCustomer;
        findCustomer = (this.isFind(cusEmail)) ?
        mapOfCustomer.get(cusEmail) : null;
        return findCustomer;
    }
    private boolean isFind(String customerEmail){
        return mapOfCustomer.containsKey(customerEmail);
    }
    public Collection<Customer> getAllCustomer(){
        return customers;
    }
    public Collection<Customer> getAllCustomers(){
        Collection<Customer> allCustomer = new ArrayList<Customer>();
        for (Customer value : mapOfCustomer.values())
            allCustomer.add(value);
        return allCustomer;
    }
    public ArrayList<String> getAllEmail(){
        ArrayList<String> allEmail = new ArrayList<String>();
        for (String email : mapOfCustomer.keySet())
            allEmail.add(email);
        return allEmail;
    }




}